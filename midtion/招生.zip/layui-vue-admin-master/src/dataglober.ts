import { ref } from "vue";
const datag = {
taken:'',
stuAll:ref([]),//普通类
stuAllf:ref([]),
stuone:ref([]),//1+2
stuR:ref([]),//艺体
stuH:ref([]),//高中
stupp:ref([]),
stuadd:ref([]),
stuppid:'',
stucity:ref([]),//市州列表
stucitynuber:ref([]),//市州人数
stuRadd:ref([]),
stuRlist:ref([]),//艺体
stuRtlist:ref([]),
stuRcity:ref([]),
stuHcity:ref([]),//高中
stuotcity:ref([]),//1+2
stuootcity:ref([]),//1+2
stuhedui:ref([]),//核对
oanumber:'',
abnormal:'',
school:ref([]),
op:false,
e6a5bde689bde698afe4bda2e58aa2e4bb9be8bf9ee4baa5e4bb94e6af92:false,

op1:false,
Ae6a5bde689bde698afe4bda2e58aa2e4bb9be8bf9ee4baa5e4bb94e6af92:false,


home:[],
api:'http://43.139.68.20:5230'
}
export {datag}