export default {
    hello: "hello"
}