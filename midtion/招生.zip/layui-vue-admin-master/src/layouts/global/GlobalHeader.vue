<template>
    
</template>

<script lang="ts">
export default {
    name: "GlobalHeader"
}
</script>

<style scoped>

</style>